sap.ui.define([
  "sap/ui/core/mvc/Controller",
  "sap/ui/comp/valuehelpdialog/ValueHelpDialog",
  'sap/m/MessageToast',
  "sap/m/SearchField",
  "sap/ui/table/Column",
  "sap/m/Label",
  "sap/m/Text",
  "sap/m/ColumnListItem",
  "sap/m/Token",
  "sap/m/Column",
  "sap/ui/model/Filter",
  "sap/ui/model/FilterOperator",
  "sap/ui/model/type/String",
  "sap/m/MessageBox",
  "sap/ui/core/BusyIndicator",
  'sap/m/MessagePopover',
	'sap/m/MessageItem',
], function (Controller,
  ValueHelpDialog,
  MessageToast,
  SearchField,
  UIColumn,
  Label,
  Text,
  ColumnListItem,
  Token,
  MColumn,
  Filter,
  FilterOperator,
  TypeString,
  MessageBox,BusyIndicator,MessagePopover,MessageItem) {
  "use strict";

  return Controller.extend("com.wl.ewm.reprintlabel.controller.View1", {
          onInit: function () {
               //var user = "GGEORGE";
              var user = sap.ushell.Container.getService("UserInfo").getId(); //"BAS",
              //this.getView().byId("iduser").setValue(user);
              this.onPrinterValueHelp(user);
              var fnValidator = function (fieldSource) {
                  return (args) => {
                      var text = args.text;
                      var oToken = new Token({ key: text, text: '=' + text });
                      oToken.addCustomData(new sap.ui.core.CustomData({
                          key: "range",
                          value: {
                              exclude: false,
                              operation: "EQ",
                              keyField: fieldSource,
                              value1: text,
                              value2: null
                          },
                          writeToDom: false
                      }));
  
                      return oToken;
                  };
              };
  
              this._oMultiInputMaterial = this.byId("multiInputWithSuggestionsMaterial");
              this._oMultiInputPlant = this.byId("multiInputWithSuggestionsPlant");
              this._oMultiInputStorage = this.byId("multiInputWithSuggestionsStorage");
              this._oMultiInputBatch = this.byId("multiInputWithSuggestionsBatch");
              this._oMultiInputWarehouse = this.byId("multiInputWithSuggestionsWarehouse");
              
              this._oMultiInputMaterial.addValidator(fnValidator("Material"));
              // this._oMultiInputPlant.addValidator(fnValidator("Plant"));
            
              this._oMultiInputBatch.addValidator(fnValidator("Batch"));
              //this._oMultiInputWarehouse.addValidator(fnValidator("Warehouse"));
              

  
              this.getOwnerComponent().getModel("local").setProperty("/logVisible", false);
             
          },

    // on valuehelp click

    _onValueHelpSearchPnt: function (oEvent) {
      var sQuery = oEvent.getParameter("newValue"); // Get the search query

      // Create filters for the search fields
      var aFilters = [];
      if (sQuery) {
        aFilters.push(new Filter("bukrs", FilterOperator.Contains, sQuery));
        aFilters.push(
          new Filter("butxt", FilterOperator.Contains, sQuery)
        );
        // aFilters.push(new Filter("SAP_Description", FilterOperator.Contains, sQuery));
      } else {
        aFilters.push(new Filter("bukrs", FilterOperator.Contains, ""));
        aFilters.push(
          new Filter("butxt", FilterOperator.Contains, "")
        );
        // aFilters.push(new Filter("SAP_Description", FilterOperator.Contains, sQuery));
      }

      // Combine filters with OR operator
      var oFilter = new Filter({
        filters: aFilters,
        and: false,
      });

      // Get the table in the ValueHelpDialog and apply the filters
      var oTable = this._oValueHelpDialog.getTable();
      oTable.getBinding("rows").filter(oFilter);
    },
    //search


    // on valuehelp click

    onValueHelpWithSuggestionsRequested: function (oParameter) {
      var oValueMasterData = oParameter.getSource().getCustomData()[0].getValue()
      this._oBasicSearchFieldWithSuggestions = new SearchField();


      this.pDialogWithSuggestions = this.loadFragment({
        name: oValueMasterData.fragmentComId,
      }).then(
        function (oDialogSuggestions) {
          var oFilterBar = oDialogSuggestions.getFilterBar();
          this._oVHDWithSuggestions = oDialogSuggestions;
          this.getView().addDependent(oDialogSuggestions);

          //master value help data for access in ok,close and other function from fragment
          this._oValueMasterData = oValueMasterData;
          //dynamic key and description to fragment
          var oValueHelpDialog = oDialogSuggestions;
          var key = oValueMasterData.keyFieldName;
          var description = oValueMasterData.keyFieldDesc;
          var title = oValueMasterData.title;
          oValueHelpDialog.setKey(key)
          oValueHelpDialog.setTitle(title)
          oValueHelpDialog.setDescriptionKey(description);

          // Set key fields for filtering in the Define Conditions Tab
          oDialogSuggestions.setRangeKeyFields([
            {
              label: oValueMasterData.keyFieldName,
              key: oValueMasterData.keyFieldName,
              type: "string",
              typeInstance: new TypeString({}, {
                maxLength: oValueMasterData.keyFieldLength,
              }
              ),
            },
          ]);

          // Set Basic Search for FilterBar
          oFilterBar.setFilterBarExpanded(false);
          oFilterBar.setBasicSearch(this._oBasicSearchFieldWithSuggestions);

          // Trigger filter bar search when the basic search is fired
          this._oBasicSearchFieldWithSuggestions.attachSearch(function () {
            oFilterBar.search();
          });

          oDialogSuggestions.getTableAsync().then(
            function (oTable) {
              oTable.setModel(this.oMainModel);
              var sMaterial = this.getView().getModel("local").getProperty("/selectedMaterial");
              if (oTable.bindRows) {
                // Initialize an empty filter array
                var aFilters = [];

               
                // Bind rows to the ODataModel and add columns
                oTable.bindAggregation("rows", {
                  path: oValueMasterData.entityName,
                  filters: aFilters.length ? aFilters : null,
                   events: {
                    dataReceived: function () {
                      oDialogSuggestions.update();
                    },
                  },
                });

                oValueMasterData.columnDetails.forEach(oCol => {
                  var oColumn = new UIColumn({ label: new Label({ text: oCol.description }), template: new Text({ wrapping: false, text: `{${oCol.fieldName}}` }) });
                  oColumn.data({ fieldName: oCol.fieldName });
                  oTable.addColumn(oColumn);
                });


              }
              // Function to apply the filter for other fields

              // For Mobile the default table is sap.m.Table
              if (oTable.bindItems) {
                // Bind items to the ODataModel and add columns
                var aCell = []
                oValueMasterData.columnDetails.forEach(oCol => {
                  aCell.push(new Label({ text: `{${oCol.fieldName}}` }));
                  oTable.addColumn(new MColumn({ header: new Label({ text: oCol.description }) }));
                });

                oTable.bindAggregation("items", {
                  path: oValueMasterData.entityName,
                  // filters: aFilters, 
                  template: new ColumnListItem({
                    cells: aCell

                  }),
                  events: {
                    dataReceived: function () {
                      oDialogSuggestions.update();
                    },
                  },
                });
              }
              oDialogSuggestions.update();
            }.bind(this)
          );

          oDialogSuggestions.setTokens(
            this.byId(oValueMasterData.inputControlId).getTokens() // this._oMultiInputWithSuggestions.getTokens()
          );
          oDialogSuggestions.open();
        }.bind(this)
      );
    },

    onValueHelpWithSuggestionsOkPress: function (oEvent) {
      var oValueMasterData = this._oValueMasterData;
      var aContract = [];
      var aTokens = oEvent.getParameter("tokens");
      this.byId(oValueMasterData.inputControlId).setTokens(aTokens); // this._oMultiInputWithSuggestions.setTokens(aTokens);
      aTokens.forEach(function (oToken) {
        var sContractKey = oToken.getText();
        aContract.push(sContractKey);
        //aContract.push(oToken.getAggregation("customData")[0].getProperty("value").value1);
      }, this);
      // --filter
      var aFilter = [];
      aTokens.forEach((token) => {
        var oFilter = this._formFilter(token, oValueMasterData.keyFieldName);
        if (oFilter) aFilter.push(oFilter);
      });
      if (aContract.length > 0) {
        var oContractInput = this.getView().byId(
          oValueMasterData.inputControlId
        );
        var oModel = this.getView().getModel("local");
        // Set the collected contract to the model
        oModel.setProperty(oValueMasterData.selectedProperty, aContract);
        this.getOwnerComponent().getModel("local").setProperty("/filterData", aFilter);
       
        this.getView().byId(oValueMasterData.inputControlId).setValue("");
      } else {
      }
      this._oVHDWithSuggestions.close();
      this._onCtrInputChange();
      // this.onValueChange(); 
    },

    onValueHelpWithSuggestionsCancelPress: function () {
      this._oVHDWithSuggestions.close();
      this._onCtrInputChange();
      // this.onValueChange();
    },

    onFilterBarWithSuggestionsSearch: function (oEvent) {
      var oValueMasterData = this._oValueMasterData;
      var sSearchQuery = this._oBasicSearchFieldWithSuggestions.getValue(),
        aSelectionSet = oEvent.getParameter("selectionSet"),
        aFilters =
          aSelectionSet &&
          aSelectionSet.reduce(function (aResult, oControl) {
            if (oControl.getValue()) {
              aResult.push(
                new Filter({
                  path: oControl.getName(),
                  operator: FilterOperator.Contains,
                  value1: oControl.getValue(),
                })
              );
            }

            return aResult;
          }, []);

      aFilters.push(
        new Filter({
          filters: [
            new Filter({
              path: oValueMasterData.keyFieldName,
              operator: FilterOperator.Contains,
              value1: sSearchQuery,
            })
          ]
        })
      );

      this._filterTableWithSuggestions(
        new Filter({
          filters: aFilters,
          and: true,
        })
      );
    },

    _filterTableWithSuggestions: function (oFilter) {
      var oVHD = this._oVHDWithSuggestions;
      oVHD.getTableAsync().then(function (oTable) {
        if (oTable.bindRows) {
          oTable.getBinding("rows").filter(oFilter);
        }
        if (oTable.bindItems) {
          oTable.getBinding("items").filter(oFilter);
        }
        oVHD.update();
      });
    },

    onValueHelpWithSuggestionsAfterClose: function () {
      this._oVHDWithSuggestions.destroy();
      this._onCtrInputChange();
      // this.onValueChange();
    },
    _formFilter: function (oToken, sFieldPath) {
      var oFilterObj = {};
      if (oToken
        .getAggregation("customData") && oToken
          .getAggregation("customData")[0] && oToken
            .getAggregation("customData")[0]
            .getProperty("key")) {
        var sKeyType = oToken
          .getAggregation("customData")[0]
          .getProperty("key");
        switch (sKeyType) {
          case "row": {
            oFilterObj = new Filter({
              path: sFieldPath,
              operator: FilterOperator.EQ,
              value1: oToken.getKey(),
            });
            break;
          }
          case "range": {
            var oValue = oToken
              .getAggregation("customData")[0]
              .getProperty("value");
            oFilterObj = new Filter({
              path: sFieldPath, //oValue.keyField,
              operator: FilterOperator[oValue.operation],
              value1: oValue.value1,
              value2: oValue.value2
            });
          }
        }
      }
      // token added through validator
      else {
        oFilterObj = new Filter({
          path: sFieldPath,
          operator: FilterOperator.EQ,
          value1: oToken.getKey()
        });
      }
      return oFilterObj;
    },
    onValueChange: async function (oParameter) {
      var oValueMasterData = oParameter.getSource().getCustomData()[0].getValue()
      var contractFlag = false;
      var sContractValue = this.byId(oValueMasterData.inputControlId).getValue();
      //var sContractToken = this.byId(oValueMasterData.inputControlId).getTokens();//git          
      var aFilters = [];
      if (sContractValue) {
        aFilters = [
          new Filter(oValueMasterData.keyFieldName, FilterOperator.EQ, sContractValue),
        ];
      }

      var oModel = this.getView().getModel("local");
      // Set the collected contract to the model
      this.getOwnerComponent().getModel("local").setProperty("/filterData", aFilters);
      this.getWarehouse();

    },
    onValueChange: async function (oParameter) {
      var oValueMasterData = oParameter.getSource().getCustomData()[0].getValue()
      var contractFlag = false;
      var sContractValue = this.byId(oValueMasterData.inputControlId).getValue();
      //var sContractToken = this.byId(oValueMasterData.inputControlId).getTokens();//git          
      var aFilters = [];
      if (sContractValue) {
        aFilters = [
          new Filter(oValueMasterData.keyFieldName, FilterOperator.EQ, sContractValue),
        ];
      }

      var oModel = this.getView().getModel("local");
      // Set the collected contract to the model
      this.getOwnerComponent().getModel("local").setProperty("/filterData", aFilters);
    },
    getWarehouse:function(){
			var oModel = this.getOwnerComponent().getModel();
      var aFilter=[];
      aFilter.push(new Filter({
        path: "plant",
        operator: FilterOperator.EQ,
        value1:this._oMultiInputPlant.getValue()
    }));
			sap.ui.core.BusyIndicator.show();
			oModel.read("/ZEWM_CDS_I_WHONO",
				{
          filters: aFilter,
					success: function (oResponse) {
						sap.ui.core.BusyIndicator.hide();
            this.getView().byId("multiInputWithSuggestionsWarehouse").setValue(oResponse.results[0].warehouseno);
					}.bind(this),
					error: function (oError) {
						sap.ui.core.BusyIndicator.hide();
						MessageBox.error(this.changei18n("error"));
					}.bind(this)
				});
		},

    _onCtrInputChange: function () {
      var ctrValue = this.byId("multiInputWithSuggestionsMaterial").getValue() || this.byId("multiInputWithSuggestionsMaterial").getTokens().length > 0;

    },
    onSelectedTokenChange: function (oEvent) {
      var aTokens = oEvent.getSource().getTokens();
      var oValueMasterData=this._oValueMasterData;
				var sType = oEvent.getParameter("type"),
					aAddedTokens = oEvent.getParameter("addedTokens"),
					aRemovedTokens = oEvent.getParameter("removedTokens"),
      
       aContexts = this.getOwnerComponent().getModel("local").getProperty("/filterData");

      switch (sType) {
        
        case "removed":
          aRemovedTokens.forEach(function (oToken) {
            aContexts = aContexts.filter(function (oContext) {
              return oContext.oValue1 !== oToken.getKey();
            });
          });
          break;
        default: break;
      }
      this.getOwnerComponent().getModel("local").setProperty("/filterData", aContexts);
      this._onCtrInputChange()
    },
    //end-value help

    // Function to open the Printer Value Help Dialog
    onPrinterValueHelp: function (sUser) {
      
      var that = this;
      //var user=this.getView().byId("iduser").getValue();
      var oModel = this.getOwnerComponent().getModel();      
      BusyIndicator.show();
      oModel.read("/ZEWM_CDS_I_USER_DETAILS(UserName='"+sUser+"',UserParameter='ZLABEL_PRINTER')", {
       
          success: function (oResponse) {
            if(oResponse){
           this.getView().byId("idprinter").setValue(oResponse.UserParameterValue);
            }
           BusyIndicator.hide();   // Handle success
          }.bind(this),
          error: function (oError) {
            BusyIndicator.hide();
              // Handle error
          }.bind(this)
      });
      
     
  },
  
   _onValueHelpOkPnt: function (oEvent) {
      var aTokens = oEvent.getParameter("tokens");
      if (aTokens && aTokens.length) {
        var oToken = aTokens[0];
        var oCustomData = oToken.getAggregation("customData")[0];
        if (oCustomData) {
          var sSelectedValue = oCustomData.getProperty("value").Printer;
          console.log("Selected Printer: ", sSelectedValue);

          // Update the UI and model with the selected value
          this.getView().byId("idprinter").setSelectedKey(sSelectedValue);
          this.getOwnerComponent().getModel("local").setProperty("/selectedPrinter", sSelectedValue);
        }
      }
      this._oValueHelpPrinterDialog.close();
    },

    _onValueHelpCancelPnt: function () {
      this._oValueHelpPrinterDialog.close();
    },

    _onValueHelpAfterClosePnt: function () {
      if (this._oValueHelpPrinterDialog) {
        this._oValueHelpPrinterDialog.destroy();
        this._oValueHelpPrinterDialog = null;
      }
    },

    
    onExecutePress: function () {
      var sPlantValue = this._oMultiInputPlant.getValue(),
        //aPlantToken = this._oMultiInputPlant.getTokens(),
          sMaterialValue = this._oMultiInputMaterial.getValue(),
          aMaterialToken = this._oMultiInputMaterial.getTokens(),
          sStorageValue = this.getView().byId("multiInputWithSuggestionsStorage").getValue(),
          //aStorageToken = this._oMultiInputStorage.getTokens(),
          sBatchValue = this._oMultiInputBatch.getValue(),
          aBatchToken = this._oMultiInputBatch.getTokens(),
          sWarehouseValue = this._oMultiInputWarehouse.getValue(),
          //aWarehouseToken = this._oMultiInputWarehouse.getTokens(),
          sPostStart = this.byId("idPostDate").getValue(),
          sPostEnd = this.byId("idPostDate1").getValue(),
          sUser = this.byId("iduser").getValue(),
          sPrinter = this.byId("idprinter").getValue(),
          slabel = this.byId("idlabels").getValue(),
          aFilter = [];

  
      // Validation
      if (!aMaterialToken.length || !sPostStart || !sPostEnd  || !sPrinter || !slabel) {
          MessageToast.show("Please fill in the mandatory fields.");
          return;
      }
  
      if (!sPlantValue ) {
          MessageToast.show("Plant cannot be empty");
          return;
      }
  
      // Add plant filters
      if (sPlantValue) {
          aFilter.push(new Filter({
              path: "Plant",
              operator: FilterOperator.EQ,
              value1: sPlantValue.toUpperCase()
          }));
      }
  
      // Add material filters
      if (aMaterialToken.length > 0) {
          aMaterialToken.forEach(token => {
              var oFilter = this._formFilter(token, "Material");
              if (oFilter) aFilter.push(oFilter);
          });
      } else if (sMaterialValue) {
          aFilter.push(new Filter({
              path: "Material",
              operator: FilterOperator.EQ,
              value1: sMaterialValue.toUpperCase()
          }));
      }
  
      
      if (sStorageValue) {
          aFilter.push(new Filter({
              path: "StorageLocation",
              operator: FilterOperator.EQ,
              value1: sStorageValue.toUpperCase()
          }));
      }
  
      // Add batch filters
      if (aBatchToken.length > 0) {
          aBatchToken.forEach(token => {
              var oFilter = this._formFilter(token, "Batch");
              if (oFilter) aFilter.push(oFilter);
          });
      } else if (sBatchValue) {
          aFilter.push(new Filter({
              path: "Batch",
              operator: FilterOperator.EQ,
              value1: sBatchValue.toUpperCase()
          }));
      }

      //warehouse
      if (sWarehouseValue) {
        aFilter.push(new Filter({
            path: "Warehouse",
            operator: FilterOperator.EQ,
            value1: sWarehouseValue.toUpperCase()
        }));
    }
    
    var oFormat = sap.ui.core.format.DateFormat.getInstance({pattern: "dd/MM/yyyy"});
		
      if(oFormat.parse(sPostStart)===null || oFormat.parse(sPostEnd)===null){
        MessageToast.show("Please enter correct Posting date.");
        return;
      }
     
      // if(sEndDate.isValidValue()==="not valid"){
      //   MessageToast.show("Please enter correct start date.");
      //     return;        
      // }
  
      // Add posting date range filter
      if (sPostStart && sPostEnd) {
          aFilter.push(new Filter({
              path: "PostingDate",
              operator: FilterOperator.BT,
              value1: sPostStart,
              value2: sPostEnd
          }));
      }
  
      // Add remaining filters
      aFilter.push(new Filter({
          path: "Printer",
          operator: FilterOperator.EQ,
          value1: sPrinter
      }));
      if(sUser){
      aFilter.push(new Filter({
          path: "CreatedBy",
          operator: FilterOperator.EQ,
          value1: sUser
      }));
    }
      aFilter.push(new Filter({
          path: "copies",
          operator: FilterOperator.EQ,
          value1: slabel
      }));
  
      // Update the local model with filter data
      this.getOwnerComponent().getModel("local").setProperty("/filterData", aFilter);
  
      aFilter.forEach(function (el) {
          if (el.sPath === "Storage") el.sPath = "StorageLocation";
          if (el.sPath === "batch") el.sPath = "Batch";
      });
  
      this.fnReset();
  
      // Proceed with OData or other processing logic as required
  },  
    fnReset: function (oEvent) {
      var oReportTable = this.getView().byId("idResultTable");
      oReportTable.setEntitySet("ZEWM_CDS_I_UNPLANNED_GI");
      
      oReportTable.rebindTable();
    },
    	//before rebind table
			onBeforeRebindTable: function (oEvent) {
        this.getView().byId("reportTable").setSelectionMode("MultiToggle");
				var binding = oEvent.getParameter("bindingParams");
				var aFilter = this.getOwnerComponent().getModel("local").getProperty("/filterData");
				if (aFilter)
					aFilter.forEach(function (el) {
						binding.filters.push(el);
					});
				

			},
      onReprint:function(){
        var payload=[];
       // var sPayload={};
        var sTable = this.getView().byId("reportTable");
				var sIndex = this.getView().byId("reportTable").getSelectedIndex();
				if (sIndex === -1) {
					MessageBox.information(this.changei18n("selectrow"));
					return;
				}
				var sObject = sTable.getContextByIndex(sIndex).getObject()
				var sRow=sTable.getSelectedIndices();
				sRow.forEach(index => {
					var sdata=sTable.getContextByIndex(index).getObject();
          var sPayload={
            "WarehouseTask" : sdata.WarehouseTask,
            "WarehouseTaskItem" : sdata.WarehouseTaskItem,
            "Warehouse" : sdata.Warehouse,
            "Material" : sdata.Material,
            "MaterialName" : sdata.MaterialName,
            "Plant" : sdata.Plant,
            "Batch" : sdata.Batch,
            "StorageLocation" :sdata.StorageLocation,
            "PostingDate" : sdata.PostingDate,
            "HandlingUnit" : sdata.HandlingUnit,
            "CreatedBy" : sdata.CreatedBy,
            "Printer" : sdata.Printer,
            "copies" :sdata.copies,
            "Message" : sdata.Message,

          }
          payload.push(sPayload);
				});
       this.onReprintCreate(payload)
    },
    onReprintCreate:function(finalPayload)
    {
      var that=this;
      var oModel= this.getOwnerComponent().getModel();
     var aDeferredGroups = oModel.getDeferredGroups();
      if (!aDeferredGroups.includes("gid")) {
        aDeferredGroups = aDeferredGroups.concat(["gid"]);
        oModel.setDeferredGroups(aDeferredGroups);
      }
      
      BusyIndicator.show();
      finalPayload.forEach(
          function (payload, idx) {
            
            oModel.create("/ZEWM_CDS_I_UNPLANNED_GI", payload, {
              groupId: "gid",
              success: function (oData, oHdr) {             
               // console.log("success-create");
              }.bind(this),
              error: function (oResponse, oHdr) {
                
               // console.log("error-create");
               
              }.bind(this),
            });
          }.bind(this)
        );

        oModel.submitChanges({
          groupId: "gid",
          success: function (oData) {
           // var filterData=this.getOwnerComponent().getModel("local").getProperty("/filterData");
            this.getJson(oData);
          //this.getOwnerComponent().getModel("local").setProperty("/filterData",filterData);
          this.getOwnerComponent().getModel("local").setProperty("/logVisible",true);
           
          MessageBox.information(this.changei18n("checklog"));  
          
          //this.onReset();
            BusyIndicator.hide();
          }.bind(this),
          error: function (oError) {
        
          MessageBox.error(this.changei18n("errorreprint")); 
          this.onReset();  
          BusyIndicator.hide();}.bind(this),
        });  
    },
    getJson:function(oData)
    {
      var finalData=[];
      var oMessage = oData.__batchResponses[0].__changeResponses;
        oMessage.forEach(record => {
          var sData={};
          var sMessage=record.data.Message;
          sData={

            title:sMessage,
            type:sMessage.includes("Error") ? "Error" : "Success"
          }
          finalData.push(sData);
        });
        
          this.getView().getModel("localModel").setData(finalData);
        // Set the collected contract to the model
       // oModel.setProperty("message", finalData);
    },
    handleMessagePopoverPress:function(oEvent)
    {
     //this.getJson();
      if (!this.oMP) {
				this.createMessagePopover();
			}
			this.oMP.toggle(oEvent.getSource());
    },
    createMessagePopover:function(){
      var that = this;

			this.oMP = new MessagePopover({				
				items: {
					path:"localModel>/",
					template: new MessageItem(
						{
							title: "{localModel>title}",
							type: "{localModel>type}",
							
						})
				},
				groupItems: true
			});

			this.getView().byId("messagePopoverBtn").addDependent(this.oMP);
    },
   
    onReset:function()
    {
      this.getOwnerComponent().getModel("local").setProperty("/logVisible",false);
    this.getView().byId("idResultTable").setTableBindingPath("");
    this.getOwnerComponent().getModel("local").setProperty("/filterData","");
    this.getView().byId("idResultTable").rebindTable();
    this.getView().byId("reportTable");
    this.getView().byId("multiInputWithSuggestionsMaterial").removeAllTokens();
    this.getView().byId("multiInputWithSuggestionsPlant").setValue("");
    //this.getView().byId("multiInputWithSuggestionsStorage").setValue("");
    this.getView().byId("multiInputWithSuggestionsBatch").removeAllTokens();
    this.getView().byId("multiInputWithSuggestionsWarehouse").setValue("");
    this.getView().byId("idPostDate").setValue("");
    this.getView().byId("idPostDate1").setValue("");
    
    
      },
      changei18n:function(sText,sPlaceholder)
			{
				var oResourceBundle=this.getOwnerComponent().getModel("i18n");
				var cText=oResourceBundle.getResourceBundle().getText(sText,sPlaceholder);
				return cText;
			}

      
      

  });
});