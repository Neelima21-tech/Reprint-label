/* global QUnit */

sap.ui.require(["com/wl/ewm/reprintlabel/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
